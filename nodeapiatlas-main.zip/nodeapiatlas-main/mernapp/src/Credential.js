
let Credential="http://localhost:5000/";
export default Credential;